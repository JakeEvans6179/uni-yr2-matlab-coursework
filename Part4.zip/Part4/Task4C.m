% Given parameters
Ke = 9.01; %torque constant 
%If = 83; % Field current (A)
Ra = 0.003645; % Armature resistance (Ohms)
B = 15;
I_a = 2650; %Maximum rated current
Va_max = 600; %Maximum rated voltage
Rf = 7.2;
M = 0.1087;
max_power = 1500000; %maximum power cap on output

% Range of angular velocity (omega) from 0 to 157 rad/s (max speed)
omega_values = 0:1:157; 
torque_values = zeros(1,length(omega_values));
% Calculate the load torque at a fixed armature voltage using varying
% angular velocities

for i = 1:length(omega_values)
    omega = omega_values(i);

    T_em = M*I_a*83; %Calculate maximum rated torque

    P = T_em*omega;

    if P <= max_power
        torque_values(i) = T_em;

    else
        T_capped = max_power/omega;
        torque_values(i) = T_capped;
    end 
end
%Torque vs Angular velocity
figure;
plot(omega_values,torque_values)
xlabel('Angular velocity (rad/s)');
ylabel('Torque (N.m)');
title('Torque - speed graph');
grid on;




%Calculate output (mechanical power) for each torque value
efficiency_values = zeros(length(omega_values));

for i = 1:length(torque_values)

    omega = omega_values(i); %extract speed

    torqueinc_fric = torque_values(i) - B*omega; %resultant torque including friction

    P_out = torqueinc_fric*omega; %output power
    
    I_f = torque_values(i)/(M*I_a); %Calculate field current required

    P_in = ((torque_values(i)*Ra)/(M*I_f) + M*I_f*omega)*I_a + 600*I_f %new power in accounting for change in field current

    efficiency = (P_out/P_in) * 100;

    efficiency_values(i) = efficiency;

end


figure;
plot(omega_values,efficiency_values)
xlabel('Angular velocity (rad/s)');
ylabel('Efficiency (%)');
title('Efficiency - speed graph');
grid on;
%}