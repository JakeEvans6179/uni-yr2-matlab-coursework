clc %Clears terminal
%clear all %Clears all variables from workspace
%PartA%

addpath(genpath('C:\femm42'))
openfemm()
opendocument([pwd '\femm_template.FEM']) 
%opendocument([pwd '\femm_template_with_air_region.FEM']) 

mi_saveas('actuator.fem')

load('corep.mat')
mi_addnode(corep(:,1),corep(:,2))
for x=1:length(corep)
   mi_selectnode(corep(x,1),corep(x,2))
   mi_setnodeprop('<corep>',1)
   mi_clearselected()
end
load('moverp.mat')
mi_addnode(moverp(:,1),moverp(:,2))
for x=1:length(moverp)
   mi_selectnode(moverp(x,1),moverp(x,2))
   mi_setnodeprop('<moverp>',2)
   mi_clearselected()
end
load('coil1p.mat')
mi_addnode(coil1p(:,1),coil1p(:,2))
for x=1:length(coil1p)
   mi_selectnode(coil1p(x,1),coil1p(x,2))
   mi_setnodeprop('<coil1p>',3)
   mi_clearselected()
end
load('coil2p.mat')
mi_addnode(coil2p(:,1),coil2p(:,2))
for x=1:length(coil2p)
   mi_selectnode(coil2p(x,1),coil2p(x,2))
   mi_setnodeprop('<coil2p>',4)
   mi_clearselected()
end
load('coil3p.mat')
mi_addnode(coil3p(:,1),coil3p(:,2))
for x=1:length(coil3p)
   mi_selectnode(coil3p(x,1),coil3p(x,2))
   mi_setnodeprop('<coil3p>',5)
   mi_clearselected()
end
load('coil4p.mat')
mi_addnode(coil4p(:,1),coil4p(:,2))
for x=1:length(coil4p)
   mi_selectnode(coil4p(x,1),coil4p(x,2))
   mi_setnodeprop('<coil4p>',6)
   mi_clearselected()
end

for x=1:length(corep) %corep line segments (group 1 - represeting core)
    if x<length(corep)
        mi_addsegment(corep(x,1),corep(x,2),corep(x+1,1),corep(x+1,2))
        mi_selectsegment((corep(x,1)+corep(x+1,1))/2,(corep(x,2)+corep(x+1,2))/2)
        mi_setsegmentprop('<corep>',0,0,0,1)
        mi_clearselected()
    else 
        mi_addsegment(corep(x,1),corep(x,2),corep(1,1),corep(1,2))
        mi_selectsegment((corep(x,1)+corep(1,1))/2,(corep(x,2)+corep(1,2))/2)
        mi_setsegmentprop('<corep>',0,0,0,1)
        mi_clearselected()
    end
end

for x=1:length(moverp) %Nodes representing armature (moverp) group 2
    if x<length(moverp)
        mi_addsegment(moverp(x,1),moverp(x,2),moverp(x+1,1),moverp(x+1,2))
        mi_selectsegment((moverp(x,1)+moverp(x+1,1))/2,(moverp(x,2)+moverp(x+1,2))/2)
        mi_setsegmentprop('<moverp>',0,0,0,2)
        mi_clearselected()
    else 
        mi_addsegment(moverp(x,1),moverp(x,2),moverp(1,1),moverp(1,2))
        mi_selectsegment((moverp(x,1)+moverp(1,1))/2,(moverp(x,2)+moverp(1,2))/2)
        mi_setsegmentprop('<moverp>',0,0,0,2)
        mi_clearselected()
    end
end

for x = 1:length(coil1p) %top half of winding_1 (core1p) group 3
    if x<length(coil1p)
        mi_addsegment(coil1p(x,1),coil1p(x,2),coil1p(x+1,1),coil1p(x+1,2))
        mi_selectsegment((coil1p(x,1)+coil1p(x+1,1))/2,(coil1p(x,2)+coil1p(x+1,2))/2)
        mi_setsegmentprop('<corep>',0,0,0,3)
        mi_clearselected()
    else 
        mi_addsegment(coil1p(x,1),coil1p(x,2),coil1p(1,1),coil1p(1,2))
        mi_selectsegment((coil1p(x,1)+coil1p(1,1))/2,(coil1p(x,2)+coil1p(1,2))/2)
        mi_setsegmentprop('<coil1p>',0,0,0,3)
        mi_clearselected()
    end
end

for x = 1:length(coil2p) %bottom half of winding_1 (core2p) group 4
    if x<length(coil2p)
        mi_addsegment(coil2p(x,1),coil2p(x,2),coil2p(x+1,1),coil2p(x+1,2))
        mi_selectsegment((coil2p(x,1)+coil2p(x+1,1))/2,(coil2p(x,2)+coil2p(x+1,2))/2)
        mi_setsegmentprop('<coil2p>',0,0,0,4)
        mi_clearselected()
    else 
        mi_addsegment(coil2p(x,1),coil2p(x,2),coil2p(1,1),coil2p(1,2))
        mi_selectsegment((coil2p(x,1)+coil2p(1,1))/2,(coil2p(x,2)+coil2p(1,2))/2)
        mi_setsegmentprop('<coil2p>',0,0,0,4)
        mi_clearselected()
    end
end

for x = 1:length(coil3p) %top half of winding_2 (core3p) group 5
    if x<length(coil3p)
        mi_addsegment(coil3p(x,1),coil3p(x,2),coil3p(x+1,1),coil3p(x+1,2))
        mi_selectsegment((coil3p(x,1)+coil3p(x+1,1))/2,(coil3p(x,2)+coil3p(x+1,2))/2)
        mi_setsegmentprop('<coil3p>',0,0,0,5)
        mi_clearselected()
    else 
        mi_addsegment(coil3p(x,1),coil3p(x,2),coil3p(1,1),coil3p(1,2))
        mi_selectsegment((coil3p(x,1)+coil3p(1,1))/2,(coil3p(x,2)+coil3p(1,2))/2)
        mi_setsegmentprop('<coil3p>',0,0,0,5)
        mi_clearselected()
    end
end

for x = 1:length(coil4p) %bottom half of winding_2 (core4p) group 6
    if x<length(coil4p)
        mi_addsegment(coil4p(x,1),coil4p(x,2),coil4p(x+1,1),coil4p(x+1,2))
        mi_selectsegment((coil4p(x,1)+coil4p(x+1,1))/2,(coil4p(x,2)+coil4p(x+1,2))/2)
        mi_setsegmentprop('<coil4p>',0,0,0,6)
        mi_clearselected()
    else 
        mi_addsegment(coil4p(x,1),coil4p(x,2),coil4p(1,1),coil4p(1,2))
        mi_selectsegment((coil4p(x,1)+coil4p(1,1))/2,(coil4p(x,2)+coil4p(1,2))/2)
        mi_setsegmentprop('<coil4p>',0,0,0,6)
        mi_clearselected()
    end
end

mi_addblocklabel(50,50) 
mi_selectlabel(50,50)
mi_setblockprop('core_nonlinear',1,1,'none',1,1,0)   %Change the properties to nonlinear when runing Task4_nonlinear.m and Task5_nonlinear.m and Task5_coenergy.m
%mi_setblockprop('core_linear',1,1,'none',1,1,0)   %Change the properties to linear when runing Task4_linear.m and Task5_linear.m and Task5_coenergy.m
mi_clearselected()

mi_addblocklabel(45,0) 
mi_selectlabel(45,0)
mi_setblockprop('core_nonlinear',1,1,'none',1,2,0)   %Change the properties to nonlinear when runing Task4_nonlinear.m and Task5_nonlinear.m and Task5_coenergy.m
%mi_setblockprop('core_linear',1,1,'none',1,2,0)   %Change the properties to linear when runing Task4_linear.m and Task5_linear.m and Task5_coenergy.m
mi_clearselected()

mi_addblocklabel(45,-65) 
mi_selectlabel(45,-65)
mi_setblockprop('copper',1,1,'winding_1',1,3,100)   %Assign copper winding blocks with respective group number and turns + direction 
mi_clearselected()

mi_addblocklabel(45,-30) 
mi_selectlabel(45,-30)
mi_setblockprop('copper',1,1,'winding_1',1,4,-100)   
mi_clearselected()

mi_addblocklabel(45,30) 
mi_selectlabel(45,30)
mi_setblockprop('copper',1,1,'winding_2',1,5,100)   
mi_clearselected()

mi_addblocklabel(45,65) 
mi_selectlabel(45,65)
mi_setblockprop('copper',1,1,'winding_2',1,6,-100)   
mi_clearselected()

mi_addblocklabel(-45,0) 
mi_selectlabel(-45,0)
mi_setblockprop('air',1,1,'none',1,0,0)   
mi_clearselected()


mi_makeABC() %Femm creates an emulated open boundary

mi_probdef(0,'millimeters','planar',1E-8,20,30,0) %Set the problem definition

smartmesh(1) %0 to turn off, 1 to enable
mi_createmesh() %Generate the mesh
%mi_showmesh() %toggles to hide the mesh triangle


mi_selectsegment(20, 0)
mi_setsegmentprop('<None>', 0.5, 0, 0, 0) %Select line segments between variable air gap and set mesh size to 0.5mm
mi_clearselected()

mi_selectsegment(25.1, 0)
mi_setsegmentprop('<None>', 0.5, 0, 0, 0)
mi_clearselected()

mi_analyse()
mi_loadsolution


%% 


%Analytical method
No_turns = 100;
mu_0 = 4*pi*10^-10; % H/mm
mu_core = 1000; % Relative permeability of core material
A_core = 20*20; % Cross-sectional area of core (mm^2)
A_armature = 20*40; % Cross-sectional area of armature (mm^2)
A_airgapf = 20*20; % Cross-sectional area of fixed air gap (mm^2)
A_airgapv = 20*40; % Cross-sectional area of variable air gap (mm^2)
A_airgapf_fringing = (20 + 2*0.5) * (20 + 2*0.5); % Air gap f with fringing

% Pre-allocate arrays for storing results
g_values = 0.1:0.1:5.1; % Range of variable air gap widths from 0.1 mm to 5.1 mm in steps of 0.1 mm
Ind_fringing_values = zeros(size(g_values)); % To store inductance with fringing
Ind_values = zeros(size(g_values)); % To store inductance without fringing
Total_Ind_fringing_values = zeros(size(g_values)); % Total inductance with fringing
Total_Ind_nonfringing_values = zeros(size(g_values)); % Total inductance without fringing

% Loop over g values from 0.1 to 5.1 in steps of 0.1 mm
for i = 1:length(g_values)
    g = g_values(i); % Current value of variable air gap
    
    % Recalculate areas considering fringing effect
    A_airgapv_fringing = (20 + 2*g)*(40 + 2*g); % Air gap v with fringing
    
    % Calculate reluctances
    Reluctance_core = 145/(mu_0*mu_core*A_core);
    Reluctance_armature = (80-g)/(mu_0*mu_core*A_armature);
    Reluctance_gapf_fringing = 0.5/(mu_0*A_airgapf_fringing);
    Reluctance_gapv_fringing = g/(mu_0*A_airgapv_fringing);
    Reluctance_gapv = g/(mu_0*A_airgapv);
    Reluctance_gapf = 0.5/(mu_0*A_airgapf);
    
    % Calculate reluctance paths
    Reluctance_path_fringing = Reluctance_core + Reluctance_gapf_fringing + Reluctance_armature + Reluctance_gapv_fringing;
    Reluctance_path_nonfringing = Reluctance_core + Reluctance_gapf + Reluctance_armature + Reluctance_gapv;
    
    % Calculate inductances
    Ind_fringing = No_turns^2 / Reluctance_path_fringing;
    Ind_nonfringing = No_turns^2 / Reluctance_path_nonfringing;
    
    % Calculate total inductance (for two paths)
    Total_Ind_fringing_values(i) = 2 * Ind_fringing; %Load inductances onto array for plotting
    Total_Ind_nonfringing_values(i) = 2 * Ind_nonfringing;
end

% Plotting the results
figure;
plot(g_values, Total_Ind_fringing_values, '-b', 'DisplayName', 'Inductance with Fringing');
hold on;
plot(g_values, Total_Ind_nonfringing_values, '-r', 'DisplayName', 'Inductance without Fringing');
xlabel('Variable Gap Width (g) in mm');
ylabel('Total Inductance (H.mm)');
legend('show');
title('Inductance vs Variable Gap Width');
grid on;
hold off;


%% 

%Commented out to simulate faster, values are saved in workspace, if you
%want to run the simulation uncomment out the relevant total_indvalues and
%get_femm_values as well as for loop



%Non Linear FEMM (run this first with non linear properties)


get_femm_values = zeros(1, 51); %store 51 values (including 5.1mm position)
Total_ind_values_femm_Nonlinear = zeros(1, 51); 


% first analyse at initial position (gap = 5.1mm)
gap = 5.1; % Initial gap value (without moving armature)
get_femm_values(1) = gap; % Store initial gap

mi_analyse()
mi_loadsolution()
CP = mo_getcircuitproperties('winding_1'); % Get solution vector

Current = CP(1);
Flux_linkage = CP(3);

% Calculate Inductance for the first position
Inductance = 2 * (Flux_linkage / Current); 

Total_ind_values_femm_Nonlinear(1) = Inductance;

%Move armature and analyse remaining positions
for i = 2:51  % Now loop starts from index 2
    gap = 5.1 - (i-1)*0.1; % Compute the current gap value
    get_femm_values(i) = gap; % Store gap value
    

    % Translate by -0.1mm each step
    mi_selectgroup(2)
    mi_movetranslate(-0.1,0)
    mi_clearselected()

    mi_analyse()
    mi_loadsolution()
    CP = mo_getcircuitproperties('winding_1');

    Current = CP(1);
    Flux_linkage = CP(3);

    % Compute Inductance
    Inductance = 2 * (Flux_linkage / Current);
    Total_ind_values_femm_Nonlinear(i) = Inductance;
end


mi_selectgroup(2)
mi_movetranslate(5.0,0) % Move back to original position
mi_clearselected()

%plot results
figure;
plot(get_femm_values, Total_ind_values_femm_Nonlinear, '-r', 'DisplayName', 'Inductance of Non-linear core FEMM');
xlabel('Variable Gap Width (g) in mm');
ylabel('Total Inductance (H)');
legend('show');
title('Inductance vs Variable Gap Width (FEMM model)');
grid on;
hold off;

%}
%% 


%Next comment out above section as Non linear data stored and run section
%below (linear case), this will plot both linear and non linear on the same graph

%{

get_femm_values = zeros(1, 51); %store 51 values (including 5.1mm position) 
Total_ind_values_femm_Linear = zeros(1,51);

%Analyse initial position at 5.1mm without moving
gap = 5.1; % Initial gap value (without moving armature)
get_femm_values(1) = gap; % Store initial gap

mi_analyse()
mi_loadsolution()
CP = mo_getcircuitproperties('winding_1'); % Get solution vector

Current = CP(1);
Flux_linkage = CP(3);

% Calculate Inductance for the first position
Inductance = 2 * (Flux_linkage / Current); 

Total_ind_values_femm_Linear(1) = Inductance; % Store result for first gap width (5.1mm)

%Move the armature and analyse remaining positions
for i = 2:51  % Now loop starts from index 2
    gap = 5.1 - (i-1)*0.1; % Compute the current gap value
    get_femm_values(i) = gap; % Store gap value
    

    % Translate by -0.1mm each step
    mi_selectgroup(2)
    mi_movetranslate(-0.1,0)
    mi_clearselected()

    mi_analyse()
    mi_loadsolution()
    CP = mo_getcircuitproperties('winding_1');

    Current = CP(1);
    Flux_linkage = CP(3);

    % Compute Inductance
    Inductance = 2 * (Flux_linkage / Current);
    Total_ind_values_femm_Linear(i) = Inductance;
end

%reset armature back to 5.1mm
mi_selectgroup(2)
mi_movetranslate(5.0,0) % Move back to original position
mi_clearselected()

%plot for both linear and non linear
figure;
plot(get_femm_values, Total_ind_values_femm_Nonlinear, '-r', 'DisplayName', 'Inductance of Non-linear core FEMM');
hold on;
plot(get_femm_values, Total_ind_values_femm_Linear, '-b', 'DisplayName', 'Inductance of linear core FEMM');
xlabel('Variable Gap Width (g) in mm');
ylabel('Total Inductance (H)');
legend('show');
title('Inductance vs Variable Gap Width (FEMM model)');
grid on;
hold off;
%}
%% 



%Calculate flux linkage for Numerical method (linear, fringing  and non
%fringing)
%fringing case
current_values = 0:2.5:10;  % Current range (5 elements: 0, 2.5, 5, 7.5, 10)
Ind_fringing_step = Total_Ind_fringing_values(1:10:end);  % Extract inductance at varying gap widths (every 10th value)
disp(Ind_fringing_step);  % Display the extracted inductance values

% Initialize a matrix to store the flux linkage values (6 gaps, 5 current values)
All_fringing_flux_linkage = zeros(6, length(current_values));  % 6 gaps, 5 current values

% Indexing through each gap and current value to calculate flux linkage

for i = 1:length(Ind_fringing_step)  % Loop through each gap
    Total_inductance_fringing = Ind_fringing_step(i);  % Extract the relevant inductance for this gap
    
    % Loop through each current value to calculate flux linkage
    for j = 1:length(current_values)
        Flux_linkage = Total_inductance_fringing * current_values(j);  % Flux linkage calculation 
        All_fringing_flux_linkage(i, j) = Flux_linkage;  % Store the flux linkage for this gap and current
    end 
end

% Extract the flux linkage for each gap for plotting
gap_01f = All_fringing_flux_linkage(1, :);  % Flux linkage for 0.1mm gap
gap_11f = All_fringing_flux_linkage(2, :);  % Flux linkage for 1.1mm gap
gap_21f = All_fringing_flux_linkage(3, :);  % Flux linkage for 2.1mm gap
gap_31f = All_fringing_flux_linkage(4, :);  % Flux linkage for 3.1mm gap
gap_41f = All_fringing_flux_linkage(5, :);  % Flux linkage for 4.1mm gap
gap_51f = All_fringing_flux_linkage(6, :);  % Flux linkage for 5.1mm gap

% Plot the flux linkage against current for each gap
figure;
plot(current_values, gap_01f, '-b', 'DisplayName', '0.1mm gap');
hold on;
plot(current_values, gap_11f, '-r', 'DisplayName', '1.1mm gap');
plot(current_values, gap_21f, '-g', 'DisplayName', '2.1mm gap');
plot(current_values, gap_31f, '-y', 'DisplayName', '3.1mm gap');
plot(current_values, gap_41f, '-p', 'DisplayName', '4.1mm gap');
plot(current_values, gap_51f, '-k', 'DisplayName', '5.1mm gap');
xlabel('Current (A)');
ylabel('Flux linkage');
legend('show');
title('Flux linkage vs Current (Fringing analytical)');
grid on;
hold off;



%Now calculate co-energy value for open and closed (extremes)
%Since it's straight line can find area under the triangle (max current*max
%flux linkage) *1/2

max_current = current_values(end);

max_flux_linkage_51f = gap_51f(end); %extract max flux linkage from list
max_fluxlinkage_01f = gap_01f(end);

co_energy_openf = max_flux_linkage_51f*max_current*0.5
co_energy_closedf = max_fluxlinkage_01f*max_current*0.5

co_energy_values_fringing = zeros(1,6);
index = 1;
for i = 6:-1:1
    co_energy = All_fringing_flux_linkage(i,end)*10*(1/2); %Want the first element to be for 5.1mm gap

    co_energy_values_fringing(index) = co_energy;

    index = index + 1;

end


%% 




%Do for non fringing model and plot again

%nonfringing case    

Ind_nonfringing_step = Total_Ind_nonfringing_values(1:10:end);  % Extract inductance at varying gap widths (every 10th value)
disp(Ind_nonfringing_step);  % Display the extracted inductance values

%Initialize a matrix to store the flux linkage values (6 gaps, 5 current values)
All_nonfringing_flux_linkage = zeros(6, length(current_values));  % 6 gaps, 5 current values

%Indexing through each gap and current value to calculate flux linkage

for i = 1:length(Ind_nonfringing_step)  %Loop through each gap
    Total_inductance_nonfringing = Ind_nonfringing_step(i);  %Extract the relevant inductance for this gap
    
    %Loop through each current value to calculate flux linkage
    for j = 1:length(current_values)
        Flux_linkage = Total_inductance_nonfringing * current_values(j);  %Flux linkage calculation 
        All_nonfringing_flux_linkage(i, j) = Flux_linkage;  %Store the flux linkage for this gap and current
    end 
end

%Extract the flux linkage for each gap for plotting
gap_01nf = All_nonfringing_flux_linkage(1, :);  %Flux linkage for 0.1mm gap
gap_11nf = All_nonfringing_flux_linkage(2, :);  
gap_21nf = All_nonfringing_flux_linkage(3, :);  
gap_31nf = All_nonfringing_flux_linkage(4, :);  
gap_41nf = All_nonfringing_flux_linkage(5, :);  
gap_51nf = All_nonfringing_flux_linkage(6, :);  %Flux linkage for 5.1mm gap

%flux linkage against current for each gap
figure;
plot(current_values, gap_01nf, '-b', 'DisplayName', '0.1mm gap');
hold on;
plot(current_values, gap_11nf, '-r', 'DisplayName', '1.1mm gap');
plot(current_values, gap_21nf, '-g', 'DisplayName', '2.1mm gap');
plot(current_values, gap_31nf, '-y', 'DisplayName', '3.1mm gap');
plot(current_values, gap_41nf, '-p', 'DisplayName', '4.1mm gap');
plot(current_values, gap_51nf, '-k', 'DisplayName', '5.1mm gap');
xlabel('Current (A)');
ylabel('Flux linkage');
legend('show');
title('Flux linkage vs Current (Non Fringing analytical)');
grid on;
hold off;

%co energy for non fringing analytical method, use same equation as above
max_flux_linkage_51nf = gap_51nf(end); %extract max flux linkage from list
max_fluxlinkage_01nf = gap_01nf(end);

co_energy_opennf = max_flux_linkage_51nf*max_current*0.5
co_energy_closednf = max_fluxlinkage_01nf*max_current*0.5

co_energy_values_nonfringing = zeros(1,6);
index = 1;
for i = 6:-1:1
    co_energy = All_nonfringing_flux_linkage(i,end)*10*(1/2); %Want the first element to be for 5.1mm gap

    co_energy_values_nonfringing(index) = co_energy;

    index = index + 1;

end


%% 


%Now using FEMM model to calculate flux linkage for Linear and Non linear
%models
%{
%Linear model - run bottom section first with non linear properties, then comment out and run
%this section with linear properties 

gap_positions = [5.1,4.1,3.1,2.1,1.1,0.1];
flux_linkage_femm_linear = zeros(6,length(current_values)); %matrix for storing calculated flux linkage wrt current values set by us


%Use current values defined earlier (current_values)

%Initial state where gap length is 5.1mm
for c = 1:length(current_values)
    I = current_values(c)

    %Set winding current values
    

        % Set the winding current values for winding 1 and winding 2
    
    mi_modifycircprop('winding_1', 1, I);
    mi_modifycircprop('winding_2', 1, I);
   
    

    mi_analyse();
    mi_loadsolution();

    CP = mo_getcircuitproperties('winding_1')
    Flux_linkage = CP(3);

    flux_linkage_femm_linear(1,c) = Flux_linkage*2;

end

%Now for cases when we move the armature

for g = 2:length(gap_positions)

    gap = gap_positions(g);

    %Move armature
    mi_selectgroup(2);
    mi_movetranslate(-1,0);
    mi_clearselected();

    for c = 1:length(current_values)

        I = current_values(c);

        %Set winding current values
        mi_modifycircprop('winding_1', 1, I); 
        mi_modifycircprop('winding_2', 1, I);

        mi_analyse();
        mi_loadsolution();

        CP = mo_getcircuitproperties('winding_1');
        Flux_linkage = CP(3);

        flux_linkage_femm_linear(g,c) = Flux_linkage*2;

    end

end

mi_selectgroup(2);
mi_movetranslate(5.0,0); %Move back to original position
mi_clearselected();

figure;
hold on;
plot(current_values, flux_linkage_femm_linear(1, :), '-b', 'DisplayName', '5.1mm gap');
plot(current_values, flux_linkage_femm_linear(2, :), '-r', 'DisplayName', '4.1mm gap');
plot(current_values, flux_linkage_femm_linear(3, :), '-g', 'DisplayName', '3.1mm gap');
plot(current_values, flux_linkage_femm_linear(4, :), '-y', 'DisplayName', '2.1mm gap');
plot(current_values, flux_linkage_femm_linear(5, :), '-p', 'DisplayName', '1.1mm gap');
plot(current_values, flux_linkage_femm_linear(6, :), '-k', 'DisplayName', '0.1mm gap');
xlabel('Current (A)');
ylabel('Total Flux Linkage');
title('Flux Linkage vs Current (FEMM Model linear)');
legend('show', 'Location', 'northwest');
grid on;
hold off;

%Calculate co energy for open and closed 
coenergy_linfemm_open = trapz(flux_linkage_femm_linear(1,:), current_values)
coenergy_linfemm_closed = trapz(flux_linkage_femm_linear(6,:), current_values)
co_energy_values_femmlinear = zeros(1,6);

for i = 1:6
    co_energy_values_femmlinear(1,i) = trapz(flux_linkage_femm_linear(i,:), current_values); %Calculate co energy values from 5.1 down to 0.1 in steps of 1mm

end

%}

%% 


%Non linear model - Run this section after running above section with non
%linear properties selected 

current_values_new = 0:1:10; %Since graph is not linear, calculate flux linkage for more current values between 0 and 10A
gap_positions = [5.1,4.1,3.1,2.1,1.1,0.1];
flux_linkage_femm_Nonlinear = zeros(6,length(current_values_new)); %matrix for storing calculated flux linkage wrt current values set by us

co_energy_values_femmnonlinear = zeros(1,length(gap_positions)); %Current is already set to 10A at this point so can calculate co energy directly
mi_analyse();
mi_loadsolution();
mo_groupselectblock();
co_energy_values_femmnonlinear(1) = mo_blockintegral(17); %Gap is currently at 5.1mm so calculate co energy at this point and put onto co energy array
mo_clearblock();

%Initial state where gap length is 5.1mm
for c = 1:length(current_values_new)
    I = current_values_new(c)

    %Set winding current values
    

        % Set the winding current values for winding 1 and winding 2
    
    mi_modifycircprop('winding_1', 1, I);
    mi_modifycircprop('winding_2', 1, I);
   
    

    mi_analyse();
    mi_loadsolution();

    CP = mo_getcircuitproperties('winding_1')
    Flux_linkage = CP(3);

    flux_linkage_femm_Nonlinear(1,c) = Flux_linkage*2;

end

%Now for cases when we move the armature (starting from 4.1mm)

for g = 2:length(gap_positions)

    gap = gap_positions(g);

    %Move armature
    mi_selectgroup(2);
    mi_movetranslate(-1,0);
    mi_clearselected();

    mi_analyse();
    mi_loadsolution();
    mo_groupselectblock();
    co_energy_values_femmnonlinear(g) = mo_blockintegral(17); %Translate gap, current at 10A from previous loop, calculate co energy and put onto array
    mo_clearblock();


    for c = 1:length(current_values_new)

        I = current_values_new(c);

        %Set winding current values
        mi_modifycircprop('winding_1', 1, I); 
        mi_modifycircprop('winding_2', 1, I);

        mi_analyse();
        mi_loadsolution();

        CP = mo_getcircuitproperties('winding_1');
        Flux_linkage = CP(3);

        flux_linkage_femm_Nonlinear(g,c) = Flux_linkage*2;

    end

end

%Calculate the co energy armature is currently in 0.1mm (closed position)



mi_selectgroup(2);
mi_movetranslate(5.0,0); %Move back to original position
mi_clearselected();



figure;
hold on;
plot(current_values_new, flux_linkage_femm_Nonlinear(1, :), '-b', 'DisplayName', '5.1mm gap');
plot(current_values_new, flux_linkage_femm_Nonlinear(2, :), '-r', 'DisplayName', '4.1mm gap');
plot(current_values_new, flux_linkage_femm_Nonlinear(3, :), '-g', 'DisplayName', '3.1mm gap');
plot(current_values_new, flux_linkage_femm_Nonlinear(4, :), '-y', 'DisplayName', '2.1mm gap');
plot(current_values_new, flux_linkage_femm_Nonlinear(5, :), '-p', 'DisplayName', '1.1mm gap');
plot(current_values_new, flux_linkage_femm_Nonlinear(6, :), '-k', 'DisplayName', '0.1mm gap');
xlabel('Current (A)');
ylabel('Total Flux Linkage');
title('Flux Linkage vs Current (FEMM Model Non linear)');
legend('show', 'Location', 'northwest');
grid on;
hold off;



%}



%% 
%Task 3.12 calculating the force varying with distance

%Emech = co energy closed - co energy open 
%Force = Emech/ gopen - gclosed

%Analytical fringing case
Force_fringing = zeros(1,6);
for i = 1:6
    co_open = co_energy_values_fringing(i);
    gap = gap_positions(i);

    deltx = (gap - 0.1)*0.001;
    Emech = co_energy_values_fringing(end) - co_open;

    Force = Emech/deltx;

    Force_fringing(i) = Force;

end

figure;
hold on;
plot(gap_positions, Force_fringing, '-b');

xlabel('airgap (mm)');
ylabel('Force (N)');
title('Force vs airgap (analytical fringing)');
grid on;
hold off;


%Analytical Non Fringing case

Force_nonfringing = zeros(1,6);
for i = 1:6
    co_open = co_energy_values_nonfringing(i);
    gap = gap_positions(i);

    deltx = (gap - 0.1)*0.001;
    Emech = co_energy_values_nonfringing(end) - co_open;

    Force = Emech/deltx;

    Force_nonfringing(i) = Force;

end

figure;
hold on;
plot(gap_positions, Force_nonfringing, '-b');

xlabel('airgap (mm)');
ylabel('Force (N)');
title('Force vs airgap (analytical non fringing)');
grid on;
hold off;

%FEMM linear case
%Run then you have linear core properties set

%{
Force_femmlinear = zeros(1,6);
for i = 1:6
    co_open = co_energy_values_femmlinear(i);
    gap = gap_positions(i);

    deltx = (gap - 0.1)*0.001;
    Emech = co_energy_values_femmlinear(end) - co_open;

    Force = Emech/deltx;

    Force_femmlinear(i) = Force;

end

figure;
hold on;
plot(gap_positions, Force_femmlinear, '-b');

xlabel('airgap (mm)');
ylabel('Force (N)');
title('Force vs airgap (FEMM linear)');
grid on;
hold off;
%}



%%
%Femm non linear 
%Run when you have non linear properties selected


Force_femmnonlinear = zeros(1,6);
for i = 1:6
    co_open = co_energy_values_femmnonlinear(i);
    gap = gap_positions(i);

    deltx = (gap - 0.1)*0.001;
    Emech = co_energy_values_femmnonlinear(end) - co_open;

    Force = Emech/deltx;

    Force_femmnonlinear(i) = Force;

end

figure;
hold on;
plot(gap_positions, Force_femmnonlinear, '-b');

xlabel('airgap (mm)');
ylabel('Force (N)');
title('Force vs airgap (FEMM non linear)');
grid on;
hold off;

%}

%%

%Plots the force gap graph for both analytical and femm methods
%Run when non linear values are generated and you are running for linear
%values

%{
figure;
hold on;
plot(gap_positions, Force_femmnonlinear, 'DisplayName', 'Non linear');
plot(gap_positions, Force_femmlinear, 'DisplayName', 'Linear');
xlabel('airgap (mm)');
ylabel('Force (N)');
title('Force vs airgap (FEMM model)');
legend('show')
grid on;
hold off;

figure;
hold on;
plot(gap_positions, Force_nonfringing, 'DisplayName', 'Non fringing');
plot(gap_positions, Force_fringing, 'DisplayName', 'Fringing');
xlabel('airgap (mm)');
ylabel('Force (N)');
title('Force vs airgap (Analytical)');
legend('show')
grid on;
hold off;

%}